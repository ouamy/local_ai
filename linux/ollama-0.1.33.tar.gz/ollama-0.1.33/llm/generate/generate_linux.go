package generate

//go:generate bash ./gen_linux.sh
