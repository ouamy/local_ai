package generate

//go:generate powershell -ExecutionPolicy Bypass -File ./gen_windows.ps1
