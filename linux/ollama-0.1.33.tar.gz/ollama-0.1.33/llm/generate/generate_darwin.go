package generate

//go:generate bash ./gen_darwin.sh
