package readline

func handleCharCtrlZ(fd int, state any) (string, error) {
	// not supported
	return "", nil
}
