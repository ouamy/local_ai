# Ollama Jupyter Notebook

This example downloads and installs Ollama in a Jupyter instance such as Google Colab. It will start the Ollama service and expose an endpoint using `ngrok` which can be used to communicate with the Ollama instance remotely.

For best results, use an instance with GPU accelerator.
